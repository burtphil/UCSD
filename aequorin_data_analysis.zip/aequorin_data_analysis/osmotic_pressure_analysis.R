
setwd("C:\\Users\\Philipp\\OneDrive\\Uni\\UCSD\\projects\\aequorin_data_analysis\\csv_files\\osmotic_pressure")
##########################################################################################
##########################################################################################
##########################################################################################

require(dplyr)
require(ggplot2)
require(tidyr)
require(base)
require(ggthemes)

##########################################################################################
##############################     define functions    ###################################
##########################################################################################

##### if I add a plate variable, I need to specify it in gather as -plate

tidyit <- function(df){
  tidy_df <- gather(df, line, lum, -Time, -plate)
  return(tidy_df)
}

### end tidy function


### normalize function

normalize <- function(df){
  
  norm <- mutate(df, luminescence = lum / (tot_aeq + lum))
  #  norm1 <- gather(norm, norm_method, luminescence, lum_norm,lum_norm2)
  
  return(norm)
  
}
#### calculate cacl2

calc <- function(df){
  
  ca <- mutate(df, luminescence = ifelse(luminescence > 0, luminescence, 0.0000005))
  ca1 <-mutate(ca, cacl2 = (10^9)*(10^-(5.5593-0.332588*log10(luminescence*10))))
  return(ca1)
}

### end cacl2 calculation


### baseline correction function

baseline_correct <- function(df){
  
  bl_c <- mutate(df, lum = lum - 47)
  
  return(bl_c)
}

### end baseline correction function


### define cutoff function

cutoff <- function(df){
  
  cut <- filter(df, tot_aeq > 40000)
  
  return(cut)
}

### end cutoff function

### calculate total aequorin function

aequorin_sum <- function(df){
  
  total_aeq <- group_by(df, line, plate)
  total_aeq_1 <- summarize(total_aeq, tot_aeq = sum(lum))
  
  return(total_aeq_1)
  
}

### tidying funcions

remove_na <- function (df){
  dummy <- df[ , colSums(is.na(df)) == 0]
  return(dummy)
}


convert_time <- function (i) {
  dummi <- mutate(i, Time = as.numeric(Time)/10) 
  return(dummi)
}

remove_inject <- function (i) {
  dummi2 <- filter(i, (Time != 5.5 ) & (Time != 5.6))
  return(dummi2)
}


###############################################################################
############################## read data files ################################
###############################################################################

# reads all files containing csv extension and stores them in read data

osm_names <- list.files(pattern = "osm.csv")
osm_data <- lapply(osm_names, function (i){
  read.csv(i,skip = 2, na.strings = c(""," ","NA","PER WELL"))})


aeq_names <- list.files(pattern = "aeq.csv")
aeq_data <- lapply(aeq_names, function (i){
  read.csv(i,skip = 2, na.strings = c(""," ","NA","PER WELL"))})

##############################################################################
################################ prepare data for analysis ###################
##############################################################################

##################### remove columns containing nas ##########################

# remove nas (function defined previously)

osm_data <- lapply(osm_data, remove_na)
aeq_data <- lapply(aeq_data, remove_na)


########################### change time column ###############################

osm_data <- lapply(osm_data, convert_time)

aeq_data <- lapply(aeq_data, convert_time)

########################### remove inject row ################################

#osm_data <- lapply(osm_data, remove_inject)
#aeq_data <- lapply(aeq_data, remove_inject)

########################### add plate variable ###############################
for (i in  seq_along(osm_data)){osm_data[[i]] <- mutate(osm_data[[i]], plate = osm_names[i])}
for (i in  seq_along(aeq_data)){aeq_data[[i]] <- mutate(aeq_data[[i]], plate = osm_names[i])}


##############################################################################
##############################################################################

#################################

#### define variables


##############################################################################
##############################################################################
##############################    data analysis           ####################
##############################################################################




### create a list that contains all osm data and another that contains all aeq discharge data

#### tidy the psm data stored in osm list and aeq data stored in aeq list

tidy_osm <- lapply(osm_data, tidyit)
tidy_aeq <- lapply(aeq_data, tidyit)

### merge data from all plates into a huge dataframe

##############################################################################
##############################################################################
##############################    testing           ####################

test1 <- tidy_osm[[3]]



##############################################################################
##############################################################################
##############################    end testing           ######################


#### binding here might not be a good idea!
# analyze plates seperately? makes more sense scientifically bind later!
# or introduce a plate variable

bind_osm <- bind_rows(tidy_osm)
bind_aeq <- bind_rows(tidy_aeq)

#### need to change this. I want to index all elements of the list and pass it as a vector
### calculate total aequorin

### put all the analysis in a for loop?

total_aeq <- aequorin_sum(bind_aeq)


### merge total aequorin with osm data

### still need to do this
### rearrange total aeq
total_aeq <- total_aeq %>% select(plate,line,tot_aeq)

osm_merge <- left_join(bind_osm, total_aeq)

### perform cutoff

osm_cut <- cutoff(osm_merge)


### perform baseline correction

osm_base <- baseline_correct(osm_cut)

### normalization

osm_norm <- normalize(osm_base)


### rename wt and mutant to wt and mu


osm_rename <- osm_norm %>% mutate(line = substr(line,1,2))


#### rename lines

osm_final <-osm_rename %>% mutate(line = ifelse(line == "X9","9.3CO9K", line))
osm_final <-osm_final %>% mutate(line = ifelse(line == "Co","Col-0", line))

osm_cacl2 <- calc(osm_final)

### calculate mean for each timestep


osm_mean <- osm_cacl2 %>% group_by(Time, line,plate) %>% mutate(avg = mean(cacl2))

#### plot peaks with error bars

error_test <- osm_cacl2 %>% group_by(Time, line, plate) %>% summarize(avg = mean(cacl2), dev = sd(cacl2), counts = n(), se = dev / sqrt(counts))
error_test <- error_test %>% group_by(line,plate) %>% filter(avg == max(avg)) %>% select(-Time)
error_test <- ungroup(error_test)

# rename variables

error_test <- error_test %>% mutate(plate = substr(plate,12,21))
error_test <- error_test %>% mutate(plate = ifelse(plate == "1200mM_sor", "1200mM_sorb",plate))

# set factor levels
error_test$line <- factor(error_test$line, c("Col-0","9.3CO9K"))
error_test$plate <- factor(error_test$plate, c("300mM_sorb","600mM_sorb","900mM_sorb","1200mM_sorb"))

error_plot <- ggplot(error_test,aes(plate, avg, group=line))

#define dodge position

pd <- position_dodge(0.4)

# actual peak plot comes here

error_plot +geom_col(width = 0.3, aes(fill = line), color = "black", position = pd)+
  theme_few()+
  labs(x="Osmolarity [mOsmol]",y ="1. Peak [Ca2+]i [nM]")+coord_cartesian(ylim = c(0,800))+
  geom_errorbar(aes(ymin=avg-se, ymax=avg+se), width=.1, position = pd)+
  scale_y_continuous(expand = c(0,1))+
  theme(legend.title = element_blank(), legend.justification = c(0,1), legend.position = c(0.04,0.96))+
  scale_x_discrete(labels= c("300","600","900","1200"))

new_plot <- ggplot(error_test, aes(line, avg))
new_plot + geom_col(width = 0.3, aes(fill = plate), color = "black", position = pd)+
  theme_few()

### calculate cacl2 peak average for each line


peaks_avg <- osm_mean %>% group_by(line,plate) %>% summarize(peak = max(avg))


### calculate peak for each seedling
### need to check if I have to adjust due to new normalization method

peak_by_seedling <- osm_norm %>% filter(plate == "2016_12_19_600mM_sorb_osm.csv") %>% group_by(line) %>% mutate(peak = max(luminescence))

peak_by_seedling <- peak_by_seedling %>% filter(luminescence == max(luminescence))
peak_by_seedling <- ungroup(peak_by_seedling) %>% select(tot_aeq,line,peak)
peak_by_seedling <- peak_by_seedling %>% mutate(col0 = grepl("Col",line))
peak_by_seedling <- peak_by_seedling %>% filter(col0 == TRUE)

### plot total aeq and 1. peak dependency

jitter <- ggplot(peak_by_seedling, aes(x= tot_aeq, y = peak))
jitter + geom_point()+theme_few()+labs(x = "Total remaining Aequorin [A.u.]", y = "1. Peak [A.u.]")

### plot lum traces

traces <- osm_final %>% group_by(Time, line,plate) %>% summarize(mean_lum = mean(luminescence))
traces <- traces %>% mutate(plate = substr(plate,12,21))
traces <- traces %>% mutate(plate = ifelse(plate == "1200mM_sor", "1200mM_sorb",plate))

### change factor labels for line and plate
traces <- traces %>% mutate(plate = ifelse(plate == "300mM_sorb", "300 mM Sorbitol",plate))
traces <- traces %>% mutate(plate = ifelse(plate == "600mM_sorb", "600 mM Sorbitol",plate))
traces <- traces %>% mutate(plate = ifelse(plate == "900mM_sorb", "900 mM Sorbitol",plate))
traces <- traces %>% mutate(plate = ifelse(plate == "1200mM_sorb", "1200 mM Sorbitol",plate))

traces$plate <- factor(ca_traces$plate, c("300 mM Sorbitol", "600 mM Sorbitol","900 mM Sorbitol","1200 mM Sorbitol"))

traces$line <- factor(traces$line, c("Col-0","9.3CO9K"))




#### lum traces
traces_plot <- ggplot(traces, aes(x = Time, y = mean_lum))


traces_plot+geom_line(size=1.0, aes(color = line))+
  facet_grid(.~plate)+
  theme_few()+
  labs(x="Time [s]", y ="Luminescence [RLU]")+
  theme(legend.title = element_blank())
  

##### show concentration effect only for WT ####

# would be nice to show dependency peak and concentration

peak_to_error <- error_test %>% mutate(osmolarity = substr(plate,1,3))
peak_to_error <- peak_to_error %>% mutate(osmolarity = ifelse(osmolarity == "120", "1200", osmolarity))
peak_to_error <- peak_to_error %>% mutate(osmolarity = as.numeric(osmolarity))


# plot this shit

peak_to_error_plot <- ggplot(peak_to_error, aes(x = osmolarity,y = avg, color = line))

peak_to_error_plot + geom_point(shape = 0, size = 1.5)+
  geom_line(size = 1)+labs(x= "Osmolarity [mOsmol]", y="1. Peak [Ca2+]i [nM]")+
  theme_few()+theme(legend.title = element_blank())+
  coord_equal(xlim = c(0,1250),ylim = c(0,800))+
  scale_x_continuous(breaks=seq(0, 1200, 300), minor_breaks = NULL)+
  geom_errorbar(aes(ymin = avg + se, ymax = avg - se), width = 15, size =1)



### plot cacl2 traces r

ca_traces <- osm_cacl2 %>%
  group_by(Time, line,plate)%>%
  summarize(mean_ca = mean(cacl2), dev = sd(cacl2), counts = n(), se = dev / sqrt(counts))
ca_traces <- ca_traces %>% mutate(plate = substr(plate,12,21))

ca_traces <- ca_traces %>% mutate(plate = ifelse(plate == "1200mM_sor", "1200 mM Sorbitol",plate))
ca_traces <- ca_traces %>% mutate(plate = ifelse(plate == "300mM_sorb", "300 mM Sorbitol",plate))
ca_traces <- ca_traces %>% mutate(plate = ifelse(plate == "600mM_sorb", "600 mM Sorbitol",plate))
ca_traces <- ca_traces %>% mutate(plate = ifelse(plate == "900mM_sorb", "900 mM Sorbitol",plate))


### change factor levels
ca_traces$plate <- factor(ca_traces$plate, c("300 mM Sorbitol", "600 mM Sorbitol","900 mM Sorbitol","1200 mM Sorbitol"))
ca_traces$line <- factor(ca_traces$line, c("Col-0","9.3CO9K"))


ca_traces_plot <- ggplot(ca_traces, aes(x = Time, y = mean_ca, color = plate))
#### change linetype for plate
ca_traces_plot+geom_line(size=1.0)+facet_grid(.~line)+
  theme_few()+
  labs(x="Time [s]", y ="[Ca2+]i [nM]")+
  theme(legend.title = element_blank())+
  scale_color_few(labels = c("1200 mOsmol", "900 mOsmol", "600 mOsmol", "300 mOsmol"))+
  coord_cartesian(ylim = c(0,800))+
  scale_x_continuous(expand = c(0,1))+
  scale_y_continuous(expand = c(0,1))

ca_traces_plot_2 <- ggplot(ca_traces, aes(x = Time, y = mean_ca))
#### change linetype for plate
ca_traces_plot+geom_line(size=1.0, aes(color = line))+
  facet_grid(.~plate)+
  theme_few()+
  labs(x="Time [s]", y ="[Ca2+]i [nM]")+
  theme(legend.title = element_blank())+
  coord_cartesian(ylim = c(0,800))+
  scale_x_continuous(expand = c(0,1))+
  scale_y_continuous(expand = c(0,1))


ca_integral <- ca_traces %>% filter(Time >= 5 && Time <= 40)%>%
  group_by(plate,line)%>%
  summarize(norm_ca_counts = sum(mean_ca), sum_se = sum(se))%>%
  mutate(line = ifelse(line == "Col-0","Col-0:35S Aeq","9.3CO9K"))

ca_integral$line <- factor(ca_integral$line, c("Col-0:35S Aeq","9.3CO9K"))

ca_integral_plot <- ggplot(ca_integral, aes(plate, norm_ca_counts, group=line))
  
ca_integral_plot+
  geom_col(width= 0.3 , aes(fill= line), position = pd, color = "black")+
  theme_few()+
  theme(legend.title = element_blank())+
  labs(x="",y="Total stimulus induced [Ca2+]i [nM]")+
  geom_errorbar(aes(ymin=norm_ca_counts-sum_se, ymax=norm_ca_counts+sum_se), width=.1, position = pd)+
  coord_cartesian(ylim = c(0,200000))+
  scale_y_continuous(expand = c(0,1))
