
setwd("C:\\Users\\Philipp\\OneDrive\\Uni\\UCSD\\projects\\aequorin_data_analysis\\csv_files\\osmotic_agents")
##########################################################################################
##########################################################################################
##########################################################################################

require(dplyr)
require(ggplot2)
require(tidyr)
require(ggthemes)

##########################################################################################
##############################     define functions    ###################################
##########################################################################################

##### if I add a plate variable, I need to specify it in gather as -plate

tidyit <- function(df){
  tidy_df <- gather(df, line, lum, -Time, -plate)
  return(tidy_df)
}

### end tidy function
showme <- aeq_data[[1]]

### normalize function

normalize <- function(df){
  
  norm <- mutate(df, luminescence = lum / (tot_aeq + lum))
  #  norm1 <- gather(norm, norm_method, luminescence, lum_norm,lum_norm2)
  
  return(norm)
  
}
#### calculate cacl2

calc <- function(df){
  
  ca <- mutate(df, luminescence = ifelse(luminescence > 0, luminescence, 0.0000005))
  ca1 <-mutate(ca, cacl2 = (10^9)*(10^-(5.5593-0.332588*log10(luminescence*10))))
  return(ca1)
}

### end cacl2 calculation


### baseline correction function

baseline_correct <- function(df){
  
  bl_c <- mutate(df, lum = lum - 47)
  
  return(bl_c)
}

### end baseline correction function


### define cutoff function

cutoff <- function(df){
  
  cut <- filter(df, tot_aeq > 40000)
  
  return(cut)
}

### end cutoff function

### calculate total aequorin function

aequorin_sum <- function(df){
  
  total_aeq <- group_by(df, line, plate)
  total_aeq_1 <- summarize(total_aeq, tot_aeq = sum(lum))
  
  return(total_aeq_1)
  
}

### tidying funcions

remove_na <- function (df){
  dummy <- df[ , colSums(is.na(df)) == 0]
  return(dummy)
}


convert_time <- function (i) {
  dummi <- mutate(i, Time = as.numeric(Time)/10) 
  return(dummi)
}

remove_inject <- function (i) {
  dummi2 <- filter(i, (Time != 5.5 ) & (Time != 5.6))
  return(dummi2)
}


###############################################################################
############################## read data files ################################
###############################################################################

# reads all files containing csv extension and stores them in read data

osm_names <- list.files(pattern = "osm.csv")
osm_data <- lapply(osm_names, function (i){
  read.csv(i,skip = 2, na.strings = c(""," ","NA","PER WELL"))})


aeq_names <- list.files(pattern = "aeq.csv")
aeq_data <- lapply(aeq_names, function (i){
  read.csv(i,skip = 2, na.strings = c(""," ","NA","PER WELL"))})


iwanttoknow <- osm_data[[1]]
##############################################################################
################################ prepare data for analysis ###################
##############################################################################

##################### remove columns containing nas ##########################

# remove nas (function defined previously)

osm_data <- lapply(osm_data, remove_na)
aeq_data <- lapply(aeq_data, remove_na)


########################### change time column ###############################

osm_data <- lapply(osm_data, convert_time)

aeq_data <- lapply(aeq_data, convert_time)

########################### remove inject row ################################

#osm_data <- lapply(osm_data, remove_inject)
#aeq_data <- lapply(aeq_data, remove_inject)

########################### add plate variable ###############################
for (i in  seq_along(osm_data)){osm_data[[i]] <- mutate(osm_data[[i]], plate = osm_names[i])}
for (i in  seq_along(aeq_data)){aeq_data[[i]] <- mutate(aeq_data[[i]], plate = osm_names[i])}


##############################################################################
##############################################################################

#################################

#### define variables

##############################################################################
##############################################################################
##############################    data analysis           ####################
##############################################################################




### create a list that contains all osm data and another that contains all aeq discharge data

#### tidy the psm data stored in osm list and aeq data stored in aeq list
test0 <- osm_data[[4]]


tidy_osm <- lapply(osm_data, tidyit)
test00 <- tidy_osm[[4]]
tidy_aeq <- lapply(aeq_data, tidyit)

### merge data from all plates into a huge dataframe

##############################################################################
##############################################################################
##############################    testing           ####################

test1 <- tidy_osm[[2]]



##############################################################################
##############################################################################
##############################    end testing           ######################


#### binding here might not be a good idea!
# analyze plates seperately? makes more sense scientifically bind later!
# or introduce a plate variable

bind_osm <- bind_rows(tidy_osm)
bind_aeq <- bind_rows(tidy_aeq)

#### need to change this. I want to index all elements of the list and pass it as a vector
### calculate total aequorin

### put all the analysis in a for loop?

total_aeq <- aequorin_sum(bind_aeq)


### merge total aequorin with osm data

### still need to do this
### rearrange total aeq
total_aeq <- total_aeq %>% select(plate,line,tot_aeq)

osm_merge <- left_join(bind_osm, total_aeq)

### perform cutoff

osm_cut <- cutoff(osm_merge)


### perform baseline correction

osm_base <- baseline_correct(osm_cut)

### normalization

osm_norm <- normalize(osm_base)


### rename wt and mutant to wt and mu


osm_rename <- osm_norm %>% mutate(line = substr(line,1,2))


#### rename lines

osm_final <-osm_rename %>% mutate(line = ifelse(line == "X9","9.3CO9K", line))
osm_final <-osm_final %>% mutate(line = ifelse(line == "Co","Col-0", line))
osm_final <-osm_final %>% mutate(line = ifelse(line == "WT","Col-0", line))

osm_final <-osm_final %>% mutate(line = ifelse(line == "MU","9.3CO9K", line))

osm_cacl2 <- calc(osm_final)

### add concentration variable as substring from plate variable
osm_cacl2 <- osm_cacl2 %>% mutate(concentration = substr(plate,12,21))
osm_cacl2 <- osm_cacl2 %>% mutate(concentration = ifelse(concentration == "water_osm.", "ddH2O", concentration))
osm_cacl2 <- osm_cacl2 %>% mutate(concentration = ifelse(concentration == "_osm.csv", "MS", concentration))
osm_cacl2 <- osm_cacl2 %>% mutate(concentration = ifelse(concentration == "0mMNaCl_os", "300 mM NaCl 2", concentration))

### plot 5 individual traces from 600 mM sorbitol

## choose random sample of 3 per line
indies <- osm_norm %>% filter(plate == "2016_12_19_600mM_sorb_osm.csv")
indies <- calc(indies)
indies2 <- indies[1:5424,]
indies3 <- indies2 %>% select(Time,line,cacl2) %>% mutate(type = substr(line,1,2))
## plot dis
indies3 <- indies
indies3 <- indies3[1:2712,]
indi_traces <- ggplot(indies3, aes(x = Time, y = cacl2))


indi_traces+geom_line(size=1.0, aes(color = line))+
  facet_grid(.~type)+
  theme_few()+
  labs(x="Time [s]", y ="1. Peak [Ca2+]i [nM]")+
  theme(legend.title = element_blank())



### plot avg peaks

error_test <- osm_cacl2 %>% group_by(Time, line, concentration) %>% summarize(avg = mean(cacl2), dev = sd(cacl2), counts = n(), se = dev / sqrt(counts))
error_test <- error_test %>% group_by(line, concentration) %>% filter(avg == max(avg))
error_test <- ungroup(error_test)
error_test$concentration <- factor(error_test$concentration, c("300 mM NaCl","600 mM Sorbitol","1/2 MS","ddH2O"))
error_test <- error_test %>% mutate(line = ifelse(line =="Col-0","Col-0:35S Aeq", line))
error_test$line <- factor(error_test$line, c("Col-0:35S Aeq","9.3CO9K"))

error_plot <- ggplot(error_test,aes(concentration, avg, group=line))

error_plot+
  geom_col(width = 0.3, aes(fill = line), color = "black", position = position_dodge(width = 0.4))+
  theme_few()+
  theme(legend.title = element_blank(), legend.justification = c(1,1), legend.position = c(0.99,0.99))+
  labs(x="",y ="1. Peak [Ca2+]i [nM]")+
  coord_cartesian(ylim = c(0,800))+
  geom_errorbar(aes(ymin=avg-se, ymax=avg+se), width=.1, position = position_dodge(width = 0.4))+
  scale_y_continuous(expand = c(0,1))


osm_mean <- osm_cacl2 %>% group_by(Time, line,plate) %>% mutate(avg = mean(cacl2))


### try to calculate peak time avg peak 1/2 peak and decay time in one df

summary_df <- osm_cacl2 %>% group_by(Time, line, concentration) %>% summarize(avg = mean(cacl2))

summary_df <- summary_df %>% group_by(line, concentration) %>% mutate(peak = max(avg), total_ca = sum(avg),half_time = 0.5*max(avg))
summary_df <- summary_df %>% mutate(half_time = 0.5*max(avg))

summary_df2 <- summary_df %>% filter((avg == peak) | (avg >= half_time & avg <= half_time+0.1))











####

### create a dataframe that only contains time and avg
osm_final <- osm_final %>% mutate(concentration = substr(plate,12,21))
osm_final <- osm_final %>% mutate(concentration = ifelse(concentration == "water_osm.", "ddH2O", concentration))
osm_final <- osm_final %>% mutate(concentration = ifelse(concentration == "_osm.csv", "MS", concentration))
osm_final <- osm_final %>% mutate(concentration = ifelse(concentration == "0mMNaCl_os", "300 mM NaCl 2", concentration))

osm_final <- osm_final %>% mutate(concentration = ifelse(concentration == "300mM_nacl", "300 mM NaCl", concentration))
osm_final <- osm_final %>% mutate(concentration = ifelse(concentration == "600mM_sorb", "600 mM Sorbitol", concentration))
osm_final <- osm_final %>% mutate(concentration = ifelse(concentration == "MS", "1/2 MS", concentration))


traces <- osm_final %>% group_by(Time, line,concentration) %>% summarize(mean_lum = mean(luminescence))

## change line factor levls
traces$concentration <- factor(traces$concentration, c("300 mM NaCl","600 mM Sorbitol", "1/2 MS","ddH2O"))
traces$line <- factor(traces$line, c("Col-0","9.3CO9K"))

traces_plot <- ggplot(traces, aes(x = Time, y = mean_lum))

traces_plot+geom_line(size=1.0, aes(color = line))+
  theme_few()+
  facet_grid(.~concentration)+
  labs(x="Time [s]", y ="Luminescence [RLU]")+
  theme(legend.title = element_blank())



### plot ca
osm_cacl2 <- calc(osm_final)

cacl2_traces <- osm_cacl2 %>% group_by(Time, line, concentration) %>% summarize(CaCl2 = mean(cacl2))
cacl2_traces$line <- factor(cacl2_traces$line, c("Col-0","9.3CO9K"))
cacl2_traces$concentration <- factor(cacl2_traces$concentration, c("300 mM NaCl","600 mM Sorbitol", "1/2 MS","ddH2O"))

cacl2_traces_plot <- ggplot(cacl2_traces, aes(x = Time, y = CaCl2, color = concentration))

cacl2_traces_plot + geom_line(size=1.0)+
  theme_few()+
  scale_color_few()+
  labs(x="Time [s]", y="[Ca2+]i [nM]")+
  facet_grid(.~line)+
  scale_color_few()+
  coord_cartesian(ylim = c(0,800))+
  theme(legend.title = element_blank())


cacl2_traces_plot_2 <- ggplot(cacl2_traces, aes(x = Time, y = CaCl2))

cacl2_traces_plot_2 + geom_line(size=1.0, aes(color = line))+
  theme_few()+
  facet_grid(.~concentration)+
  labs(x="Time [s]", y="[Ca2+]i [nM]")+
  coord_cartesian(ylim = c(0,800))+
  theme(legend.title = element_blank())

### anova analysis

peak_by_seedling <- osm_norm %>% group_by(line,plate) %>% summarize(peak = max(luminescence))

peak_by_seedling <-ungroup(peak_by_seedling)


#### rename line and plate factors
peak_by_seedling <- peak_by_seedling %>% mutate(line = substr(line,1,2))
peak_by_seedling <- peak_by_seedling %>% mutate(plate = substr(plate,12,21))

peak_by_seedling <-peak_by_seedling %>% mutate(line = ifelse(line == "X9","9.3CO9K", line))
peak_by_seedling <-peak_by_seedling %>% mutate(line = ifelse(line == "Co","Col-0", line))
peak_by_seedling <-peak_by_seedling %>% mutate(line = ifelse(line == "WT","Col-0", line))
peak_by_seedling <-peak_by_seedling %>% mutate(line = ifelse(line == "MU","9.3CO9K", line))
peak_by_seedling <- peak_by_seedling %>% mutate(plate = ifelse(plate == "_osm.csv", "MS", plate))

# add ca concentrations

peak_by_seedling <- peak_by_seedling %>% mutate(ca  = (10^9)*(10^-(5.5593-0.332588*log10(peak*10))))
#peaks_avg$line <- factor(peaks_avg$line, c("Col-0","Col-0 x Aeq","Col-0 x 9.3CO9K","9.3CO9K","Bak1-3 x 9.3CO9K"))

aov1 <- aov(ca ~ line*plate, data = peak_by_seedling)
tukey <- TukeyHSD(aov1)
anova_results <- tukey[[3]]
write.table(anova_results, file="osm_agents_aov.txt",sep = "\t", row.names=TRUE, col.names=TRUE)
tukey
