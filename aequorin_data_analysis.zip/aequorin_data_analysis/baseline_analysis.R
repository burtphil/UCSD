setwd("C:\\Users\\Philipp\\OneDrive\\Uni\\UCSD\\projects\\aequorin_data_analysis")
getwd()

require("tidyr")
require("dplyr")
require("ggplot2")
require("ggthemes")

uniform_test <- read.csv2("uniform_test.csv")

uniform_test <- uniform_test %>% gather(line,lum, -Time)


uniform_test <- uniform_test %>% mutate(line = substr(line,1,2))
uniform_test <- uniform_test %>% select(Time, lum) %>% filter(Time < 10)

uniform_plot <- ggplot(uniform_test, aes(x=Time, y=lum))
uniform_plot + geom_point(alpha=0.15) +theme_few()+
  labs(y="Luminescence [A.u.]", x="Time [s]")+
  geom_hline(yintercept = 47.53131, show.legend = TRUE)

summary <-uniform_test %>% summarize(mean = mean(lum))
