
setwd("C:\\Users\\Philipp\\OneDrive\\Uni\\UCSD\\projects\\aequorin_data_analysis\\csv_files\\complementation")
##########################################################################################
##########################################################################################
##########################################################################################

require(dplyr)
require(ggplot2)
require(tidyr)
require(base)
require(ggthemes)

##########################################################################################
##############################     define functions    ###################################
##########################################################################################

##### if I add a plate variable, I need to specify it in gather as -plate

tidyit <- function(df){
  tidy_df <- gather(df, line, lum, -Time, -plate)
  return(tidy_df)
}

### end tidy function


### normalize function

normalize <- function(df){
  
  norm <- mutate(df, luminescence = lum / (tot_aeq + lum))
#  norm1 <- gather(norm, norm_method, luminescence, lum_norm,lum_norm2)
  
  return(norm)
  
}
#### calculate cacl2

calc <- function(df){
  
  ca <- mutate(df, luminescence = ifelse(luminescence > 0, luminescence, 0.0000005))
  ca1 <-mutate(ca, cacl2 = (10^9)*(10^-(5.5593-0.332588*log10(luminescence*10))))
  return(ca1)
}

### end cacl2 calculation


### baseline correction function

baseline_correct <- function(df){
  
  bl_c <- mutate(df, lum = lum - 47)
  
  return(bl_c)
}

### end baseline correction function


### define cutoff function

cutoff <- function(df){
  
  cut <- filter(df, tot_aeq > 40000)
  
  return(cut)
}

### end cutoff function

### calculate total aequorin function

aequorin_sum <- function(df){
  
  total_aeq <- group_by(df, line, plate)
  total_aeq_1 <- summarize(total_aeq, tot_aeq = sum(lum))
  
  return(total_aeq_1)
  
}

### tidying funcions

remove_na <- function (df){
    dummy <- df[ , colSums(is.na(df)) == 0]
    return(dummy)
}


convert_time <- function (i) {
  dummi <- mutate(i, Time = as.numeric(Time)/10) 
  return(dummi)
}

remove_inject <- function (i) {
  dummi2 <- filter(i, (Time != 5.5 ) & (Time != 5.6))
  return(dummi2)
}


###############################################################################
############################## read data files ################################
###############################################################################

# reads all files containing csv extension and stores them in read data

osm_names <- list.files(pattern = "osm.csv")
osm_data <- lapply(osm_names, function (i){
  read.csv(i,skip = 2, na.strings = c(""," ","NA","PER WELL"))})


aeq_names <- list.files(pattern = "aeq.csv")
aeq_data <- lapply(aeq_names, function (i){
  read.csv(i,skip = 2, na.strings = c(""," ","NA","PER WELL"))})

##############################################################################
################################ prepare data for analysis ###################
##############################################################################

##################### remove columns containing nas ##########################

# remove nas (function defined previously)

osm_data <- lapply(osm_data, remove_na)
aeq_data <- lapply(aeq_data, remove_na)


########################### change time column ###############################

osm_data <- lapply(osm_data, convert_time)

aeq_data <- lapply(aeq_data, convert_time)

########################### remove inject row ################################

#osm_data <- lapply(osm_data, remove_inject)
#aeq_data <- lapply(aeq_data, remove_inject)

########################### add plate variable ###############################
for (i in  seq_along(osm_data)){osm_data[[i]] <- mutate(osm_data[[i]], plate = osm_names[i])}
for (i in  seq_along(aeq_data)){aeq_data[[i]] <- mutate(aeq_data[[i]], plate = osm_names[i])}


##############################################################################
##############################################################################

#################################

#### define variables


##############################################################################
##############################################################################
##############################    data analysis           ####################
##############################################################################




### create a list that contains all osm data and another that contains all aeq discharge data

#### tidy the psm data stored in osm list and aeq data stored in aeq list

tidy_osm <- lapply(osm_data, tidyit)
tidy_aeq <- lapply(aeq_data, tidyit)

### merge data from all plates into a huge dataframe

##############################################################################
##############################################################################
##############################    testing           ####################

test1 <- tidy_osm[[1]]



##############################################################################
##############################################################################
##############################    end testing           ######################


#### binding here might not be a good idea!
# analyze plates seperately? makes more sense scientifically bind later!
# or introduce a plate variable

bind_osm <- bind_rows(tidy_osm)
bind_aeq <- bind_rows(tidy_aeq)

#### need to change this. I want to index all elements of the list and pass it as a vector
### calculate total aequorin

### put all the analysis in a for loop?

total_aeq <- aequorin_sum(bind_aeq)


### merge total aequorin with osm data

### still need to do this
### rearrange total aeq
total_aeq <- total_aeq %>% select(plate,line,tot_aeq)

osm_merge <- left_join(bind_osm, total_aeq)

### perform cutoff

osm_cut <- cutoff(osm_merge)


### perform baseline correction

osm_base <- baseline_correct(osm_cut)

### normalization

osm_norm <- normalize(osm_base)


### rename wt and mutant to wt and mu


osm_rename <- osm_norm %>% mutate(line = substr(line,1,6))


#### rename lines

osm_final <-osm_rename %>% mutate(line = ifelse(line == "X9.3CO","9.3CO9K", line))
osm_final <-osm_final %>% mutate(line = ifelse(line == "Col0xA","Col-0 x Col-0:35S Aeq", line))
osm_final <-osm_final %>% mutate(line = ifelse(line == "Col0x9","Col-0 x 9.3CO9K", line))
osm_final <-osm_final %>% mutate(line = ifelse(line == "Col.0.","Col-0:35S Aeq", line))
osm_final <-osm_final %>% mutate(line = ifelse(line == "Col0xA","Col-0 x Col-0:35S Aeq", line))
osm_final <-osm_final %>% mutate(line = ifelse(line == "Col.0","Col-0:35S Aeq", line))
osm_final <-osm_final %>% mutate(line = ifelse(line == "Bak1.3","Bak1-3 x 9.3CO9K", line))

osm_final$line <- factor(osm_final$line, c("Col-0:35S Aeq","Col-0 x Col-0:35S Aeq","Col-0 x 9.3CO9K","Bak1-3 x 9.3CO9K","9.3CO9K"))


### calculate ca concentrations
osm_cacl2 <- calc(osm_final)

### plot avg peaks

osm_error <- osm_cacl2 %>% group_by(Time, line) %>% summarize(avg = mean(cacl2), dev = sd(cacl2), counts = n(), se = dev / sqrt(counts))
osm_error <- osm_error %>% group_by(line) %>% filter(avg == max(avg)) %>% select(-Time)
osm_error <- ungroup(osm_error)
osm_error <- osm_error %>% mutate(line = as.character(line))
osm_error <- osm_error %>% mutate(line = ifelse(line == "Col-0","Col-0:35S Aeq",line))
osm_error <- osm_error %>% mutate(line = ifelse(line == "Col-0 x Aeq","Col-0 x Col-0:35S Aeq",line))

osm_error$line <- factor(osm_error$line, c("Col-0:35S Aeq","Col-0 x Col-0:35S Aeq","Col-0 x 9.3CO9K","Bak1-3 x 9.3CO9K","9.3CO9K"))

error_plot <- ggplot(osm_error,aes(line, avg))
error_plot+
  geom_col(width = 0.2, aes(fill = line), color = "black")+
  labs(y="1. Peak [Ca2+]i [nM]", x="")+
  coord_cartesian(ylim = c(0,800))+
  geom_errorbar(aes(ymin=avg-se, ymax=avg+se), width=.1)+
  theme_few()+
  theme(legend.position="none",axis.text.x = element_text(angle = 40, vjust = 1, hjust=0.9))+
  scale_y_continuous(expand = c(0,0),breaks = seq(0,800,100))


### calculate mean for each timestep


osm_mean <- osm_cacl2 %>% group_by(Time, line) %>% mutate(avg = mean(cacl2))



### calculate peak average for each line


#peaks_avg <- osm_mean %>% group_by(line) %>% summarize(peak = max(avg))


### calculate peak for each seedling
### need to check if I have to adjust due to new normalization method

peak_by_seedling <- osm_norm %>% group_by(line,plate) %>% summarize(peak = max(luminescence))

peak_by_seedling <-ungroup(peak_by_seedling)
peak_by_seedling <- peak_by_seedling %>% mutate(line = substr(line,1,6))


peak_by_seedling <-peak_by_seedling %>% mutate(line = ifelse(line == "X9.3CO","9.3CO9K", line))
peak_by_seedling <-peak_by_seedling %>% mutate(line = ifelse(line == "Col0xA","Col-0 x Col-0:35S Aeq", line))
peak_by_seedling <-peak_by_seedling %>% mutate(line = ifelse(line == "Col0x9","Col-0 x 9.3CO9K", line))
peak_by_seedling <-peak_by_seedling %>% mutate(line = ifelse(line == "Col.0.","Col-0:35S Aeq", line))
peak_by_seedling <-peak_by_seedling %>% mutate(line = ifelse(line == "Col0xA","Col-0 x Col-0:35S Aeq", line))
peak_by_seedling <-peak_by_seedling %>% mutate(line = ifelse(line == "Col.0","Col-0:35S Aeq", line))
peak_by_seedling <-peak_by_seedling %>% mutate(line = ifelse(line == "Bak1.3","Bak1-3 x 9.3CO9K", line))

peak_by_seedling <- peak_by_seedling %>% mutate(ca  = (10^9)*(10^-(5.5593-0.332588*log10(peak*10))))
#peaks_avg$line <- factor(peaks_avg$line, c("Col-0","Col-0 x Aeq","Col-0 x 9.3CO9K","9.3CO9K","Bak1-3 x 9.3CO9K"))

aov1 <- aov(ca ~ line, data = peak_by_seedling)
tukey <- TukeyHSD(aov1)
anova_results <- tukey[[1]]
write.table(anova_results, file="complementation_aov.txt",sep = "\t", row.names=TRUE, col.names=TRUE)

### reorder col chart WT first
#peaks_avg$line <- factor(peaks_avg$line, c("Col-0","Col-0 x Aeq","Col-0 x 9.3CO9K","9.3CO9K","Bak1-3 x 9.3CO9K"))



### plot luminescence traces
### create a dataframe that only contains time and avg

traces <- osm_final %>% group_by(Time, line) %>% summarize(mean_lum = mean(luminescence))
traces_plot <- ggplot(traces, aes(x = Time, y = mean_lum, color = line))

traces_plot + geom_line(size=1.0)+theme_few()+
  labs(x="Time [s]", y ="Luminescence [RLU]")+theme(legend.title = element_blank())+
  scale_x_continuous(breaks = seq(0,45,5), expand = c(0,1))+
  coord_cartesian(ylim = c(0,0.002))

### plot cacl2 tracesr

cacl2_traces <- osm_cacl2 %>% group_by(Time, line) %>% summarize(CaCl2 = mean(cacl2))
cacl2_traces_plot <- ggplot(cacl2_traces, aes(x = Time, y = CaCl2, color = line))

cacl2_traces_plot + geom_line(size=1.0)+theme_few()+
  labs(x="Time [s]", y="[Ca2+]i [nM]")+
  scale_x_continuous(breaks = seq(0,45,5), expand = c(0,1))+
  scale_y_continuous(breaks=seq(0, 700, 100),limits = c(0,700), expand = c(0,1))+
  theme(legend.title = element_blank())



