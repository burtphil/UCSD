tidyit <- function(df){
  tidy_df <- gather(df, line, lum, -Time)
  return(tidy_df)
}

### end tidy function


### normalize function

normalize <- function(df){
  
  norm <- mutate(df, luminescence = lum / (tot_aeq))
  #  norm1 <- gather(norm, norm_method, luminescence, lum_norm,lum_norm2)
  
  return(norm)
  
}
#### calculate cacl2

calc <- function(df){
  
  ca <- mutate(df, luminescence = ifelse(luminescence > 0, luminescence, 0.0000005))
  ca1 <-mutate(ca, cacl2 = (10^9)*(10^-(5.5593-0.332588*log10(luminescence*10))))
  return(ca1)
}

### end cacl2 calculation


### baseline correction function



### end baseline correction function


### define cutoff function


### end cutoff function

### calculate total aequorin function

aequorin_sum <- function(df){
  
  total_aeq <- group_by(df, line)
  total_aeq_1 <- summarize(total_aeq, tot_aeq = sum(lum))
  
  return(total_aeq_1)
  
}

### tidying funcions

remove_na <- function (df){
  dummy <- df[ , colSums(is.na(df)) == 0]
  return(dummy)
}


convert_time <- function (i) {
  dummi <- mutate(i, Time = as.numeric(Time)/10) 
  return(dummi)
}
