
### load packages

library(shiny)
library(tidyr)
library(dplyr)
library(ggplot2)
library(ggthemes)
### function start

function(input, output) {
  
  ### source the functions for later analysis
  
  source("functions.R")
  
  ### upload osm data and aeq data
  
  upload_osm_data <- eventReactive(input$fileupload,{
    osm_data <- input$upload_osm
    if (is.null(osm_data)) {
      # User has not uploaded a file yet
      return(NULL)
    }
    read.csv(osm_data$datapath, header=input$header, sep=input$sep, 
             quote=input$quote,
             skip = input$skip_row,
             na.strings = c(""," ","NA","PER WELL","X","T..Lum"))
  })
  
  upload_aeq_data <- eventReactive(input$fileupload,{
    aeq_data <- input$upload_aeq
    if (is.null(aeq_data)) {
      # User has not uploaded a file yet
      return(NULL)
    }
    read.csv(aeq_data$datapath, header=input$header, sep=input$sep, 
             quote=input$quote,
             skip = input$skip_row,
             na.strings = c(""," ","NA","PER WELL","X","T..Lum"))
  })
  
  ### make a reactive data manipulation.
  ### output should be a merged table of the osm and aeq data
  ### should include input from baseline corrections and cutoff
  osm_remove <- reactive({
    df <- upload_osm_data()
    remove_na(df)
  })
  
  aeq_remove <- reactive({
    df <- upload_aeq_data()
    remove_na(df)
  })
  
  time_osm <- reactive({
    df <- osm_remove()
    convert_time(df)
  })
  
  time_aeq <- reactive({
    df <- aeq_remove()
    convert_time(df)
  })
  
  tidy_osm <- reactive({
    df <- time_osm()
    tidyit(df) %>% mutate(lum = lum - input$baseline)
  })
  
  tidy_aeq <- reactive({
    df <- time_aeq()
    tidyit(df) %>% mutate(lum = lum - input$baseline)
  })

  #### at the moment sum(lum) only works for "." dec. separation
  
    
  total_aeq <- reactive({
    df <- tidy_aeq()
    df %>% group_by(line) %>% summarize(tot_aeq = sum(lum))
  })
  
  osm_merge <- reactive({
    left_join(tidy_osm(), total_aeq())
  })
  
  cutoff <- reactive({
    df <- osm_merge()
    df %>% filter(tot_aeq > input$cut_it)
  })
  
  normalize <- reactive({
    df <- cutoff()
    df %>% mutate(luminescence = lum / tot_aeq)
  })
  
  calculate_ca <- reactive({
    df <- normalize()
    df %>% mutate(luminescence = ifelse(luminescence > 0, luminescence, 0.0000005),
                  cacl2 = (10^9)*(10^-(5.5593-0.332588*log10(luminescence*10))))
  })
 
  rename <- reactive({
    df <- calculate_ca()
    df %>% mutate(line = substr(line,1,2))
  })
  
  peaks <- reactive({
    df <- rename()
    df %>% group_by(Time, line)%>%
      summarize(avg = mean(cacl2), dev = sd(cacl2), counts = n(), se = dev / sqrt(counts))%>%
      ungroup() %>% group_by(line) %>% filter(avg == max(avg)) %>%
      select(-Time) %>% ungroup()
    
  })
  
  single_peaks <- reactive({
    df <- calculate_ca()
    df %>% group_by(line) %>% summarize(peak = max(cacl2)) %>% ungroup() %>%
      mutate(line = substr(line,1,2))
  })
  
  peak_aov <- reactive({
    aov1 <- aov(peak ~ line, data = single_peaks())
    TukeyHSD(aov1)
    
  })
  
  plot_peaks <- reactive({

    peak_plot <- ggplot(peaks(),aes(line, avg))
    
    peak_plot +geom_col(width = 0.3, color = "black")+
      theme_few()+
      labs(x="",y ="1. Peak [Ca2+]i [nM]")+coord_cartesian(ylim = c(0,800))+
      geom_errorbar(aes(ymin=avg-se, ymax=avg+se), width=.1)+
      scale_y_continuous(expand = c(0,1))+
      theme(legend.title = element_blank(), legend.justification = c(0,1), legend.position = c(0.04,0.96))
    
  })
   
  spread_lum <- reactive({
    df <- traces()
    df %>% spread(line, mean_lum)
      
  })
  
  spread_ca <- reactive({
    df <- ca_traces()
    df %>% spread(line, mean_ca)
  })
  
  
  
  traces <- reactive({
    df <- rename()
    df %>% group_by(Time, line) %>% summarize(mean_lum = mean(luminescence))
  })
  
  
 ca_traces <- reactive({
    df <- rename()
    df %>% group_by(Time, line) %>% summarize(mean_ca = mean(cacl2))
  })
  ### end data manipulation
  
  plot_traces <- reactive({
    traces_plot <- ggplot(traces(), aes(x = Time, y = mean_lum, color = line))
    
    traces_plot+geom_line(size=1.0)+
      theme_few()+
      labs(x="Time [s]", y ="Luminescence [RLU]")+
      theme(legend.title = element_blank())
    
  })
  
  plot_ca_traces <- reactive({
    ca_traces_plot <- ggplot(ca_traces(), aes(x = Time, y = mean_ca, color = line))
    #### change linetype for plate
    ca_traces_plot+geom_line(size=1.0)+
      theme_few()+
      labs(x="Time [s]", y ="[Ca2+]i [nM]")+
      theme(legend.title = element_blank())+
      coord_cartesian(ylim = c(0,800))+
      scale_x_continuous(expand = c(0,1))+
      scale_y_continuous(expand = c(0,1))
    
  })
  
  ### plot traces in lum_traces
  
  output$lum_traces <- renderPlot({
    plot_traces()
  })
  
  output$calcium <- renderPlot({
    plot_ca_traces()
  })
  
  output$ca_peaks <- renderPlot({
    plot_peaks()
  })
  ### print output as table
  
  output$contents <- renderTable({
    
    # input$file1 will be NULL initially. After the user selects
    # and uploads a file, it will be a data frame with 'name',
    # 'size', 'type', and 'datapath' columns. The 'datapath'
    # column will contain the local filenames where the data can
    # be found.
    
    head(rename())
    
  
  })
  
  output$raw_osm_data <- renderTable({
    
    # input$file1 will be NULL initially. After the user selects
    # and uploads a file, it will be a data frame with 'name',
    # 'size', 'type', and 'datapath' columns. The 'datapath'
    # column will contain the local filenames where the data can
    # be found.
    
   head(time_osm())
    
    
  })
  
  output$lum_df <- renderTable({
    
    head(spread_lum())
    
  })
  
  output$ca_df <- renderTable({
    
    head(spread_ca())
    
  })
  
  output$raw_aeq_data <- renderTable({
    
    head(time_aeq())
    
  })
  
  output$anova <- renderPrint({
    peak_aov()
  })
  
  output$dl_tidy_data <- downloadHandler(
    filename = "tidy_data.csv",
    content = function(file) {
      write.csv2(rename(), file)
    }
  )
  
  output$peaks_df <- renderTable({
    head(peaks())
  })
  
  output$dl_peak_data <- downloadHandler(
    filename = "peaks.csv",
    content = function(file){
      write.csv2(peaks(),file)
    }
  )
  
  output$dl_single_peaks <- downloadHandler(
    filename = "peaks.csv",
    content = function(file){
      write.csv2(single_peaks(),file)
    }
  )
  
  
  output$dl_lum_data <- downloadHandler(
    filename = "lum_data.csv",
    content = function(file) {
      write.csv2(spread_lum(), file)
    }
  )
  
  output$dl_ca_data <- downloadHandler(
    filename = "ca_data.csv",
    content = function(file) {
      write.csv2(spread_ca(), file)
    }
  )
  
  output$dl_anova <- downloadHandler(
    filename ="anova.txt",
    content = function(file) {
      capture.output(peak_aov(),file)
    }
  )
  

}

