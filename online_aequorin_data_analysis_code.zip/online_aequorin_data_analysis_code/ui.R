

library(shiny)
library(tidyr)
library(dplyr)
library(ggplot2)
library(ggthemes)

fluidPage(
  
  titlePanel("Analyze Stimulus induced Calcium Response"),
  
  tabsetPanel(
    
    tabPanel("Upload Data",
             h2(""),
             h4("Choose tabular data for analysis and adjust for the specific settings. Then click 'submit'."),
             h4("Use the 'View raw data' panel to ensure that data was loaded correctly."),
             h4("Please read the readme section when using this tool for the first time."),
             hr(),
             fluidRow(    
               ### upload osm data
               column(4,
                      fileInput('upload_osm', 'Browse Stimulus Data',
                                accept=c('text/csv', 
                                         'text/comma-separated-values,text/plain', 
                                         '.csv')),
                      ### upload aeq data
                      
                      fileInput('upload_aeq', 'Browse Aequorin Discharge Data',
                                accept=c('text/csv', 
                                         'text/comma-separated-values,text/plain', 
                                         '.csv')),
                      
                      actionButton("fileupload", "Submit Fileupload"),
                      
                      tags$hr()
                    ),
               
               column(3, offset = 1,
                      checkboxInput('header', 'Header', TRUE),
                      
                      radioButtons('sep', 'Separator',
                                   c(Comma=',',
                                     Semicolon=';',
                                     Tab='\t'),
                                   ','),
                      radioButtons('quote', 'Quote',
                                   c(None='',
                                     'Double Quote'='"',
                                     'Single Quote'="'"),
                                   '"')
                    ),
               
               #### make sliders for cutoff and baseline
               
               column(4,
                      numericInput("skip_row",
                                   label = "Skip first n rows from csv file?", value = 2, min = 0, step =1),
                      
                      sliderInput("baseline","Baseline:",
                                  min = 0, max = 100, value = 30, step= 0.5),
                      
                      sliderInput("cut_it","Cutoff:",
                                  min = 0, max = 100000, value = 50000, step= 10)
                      
                    )
             )
            ),
    
    tabPanel("Transformed data",
             tableOutput('contents'),
             wellPanel(downloadButton('dl_tidy_data', 'Download as csv'))
            ),
    
    tabPanel("View Raw Data",
             h4("Preview Stimulus Data"),
             tableOutput("raw_osm_data"),
             hr(),
             h4("Preview Discharge Data"),
             tableOutput("raw_aeq_data")
            ),
    
    tabPanel("Luminescence traces (avg)",
             
              fluidRow(
                column(7,plotOutput("lum_traces")),
                column(4,offset = 1,
                       h4("Preview luminescence Data"),
                       tableOutput("lum_df"),
                       wellPanel(downloadButton('dl_lum_data', 'Download as csv'))
                      )
                      )
              
            ),
    
    tabPanel("Calcium traces (avg)",
             
             fluidRow(
               column(7,plotOutput("calcium")),
               column(4,offset = 1,
                      h4("Preview calcium Data"),
                      tableOutput("ca_df"),
                      wellPanel(downloadButton('dl_ca_data', 'Download as csv'))
               )
             )
             
             

            ),
    
    tabPanel("Peak Data",
            fluidRow(
              column(6,
                     plotOutput("ca_peaks")
              ),
              column(6,
                     h4("Preview avg. peak data:"),
                     tableOutput("peaks_df"),
                     wellPanel(downloadButton('dl_peak_data', 'Download avg. peak data as csv')),
                     p("Download peaks from individual wells for statistical analysis:"),
                     wellPanel(downloadButton('dl_single_peaks', 'Download ind. peak data'))
              )
            ),
            hr(),
            h4("ANOVA:"),
            textOutput("anova"),
            hr(),
            p("p value corresponds to the last value. At the moment, there is no better option than to copy-paste it.")
            
            ),
    
    tabPanel("readme",
              hr(),
              p("This analysis tool is intended to analyze aequorin luminescence data."),
              p("Normalization and luminescence - Ca2+ transformation is employed as described in:"),
              p("Knight et al. (1996), 'Cold calcium signaling in Arabidopsis involves two cellular pools and a change in calcium signature after acclimation', PLANT CELL"),
              p("You can upload and specify settings as explained below."),
              hr(),
              fluidRow(
                column(6,
                  h4("Upload:"),
                  p("Upload files must be in csv format. At the moment, the software only allows analysis of one experiment at a time."),
                  p("For the program to work, the data must have a distinct format. Please look at the example file to see how your data should be provided"),
                  p("Most importantly:"),
                  p("The 'Time' column should be written with a capital 'T'."), 
                  p("Your column names for lines to analyse must be contain only 2 letters."),
                  p("At the moment, the program does not support a different way. I suggest to use e.g. WT, M1,M2,M3 - for wild type and three mutant lines. You can change the names when you download the csv data."), 
                  p("Your whole document should not contain any weird/fancy characters, it will mess with the encoding. If the app throws an error like: 'invalid multibye string', this is whats happening. "),
                  hr(),
                  a("This is how your data should look like (clickme)",target="_blank",href="readme_cs.png"),
                  hr(),
                  p("Written by Philipp Burt, Student University of California/ Humboldt University of Berlin")
                ),
                
                column(5, offset=1,
                  h4("Settings:"),
                  p("Baseline:"),
                  p("This corrects for background noise in the data. The background noise might vary from machine to machine and between experiments. Look at your data and check if the background spectra fit a uniform distribution."),
                  p("Baseline correction substracts the user input value from all data points."),
                  p("Cutoff:"),
                  p("Cutoff is equal to the total remaining aequorin. All wells with aequorin levels under this threshold after baseline correction will be excluded."),
                  p("Skip lines:"),
                  p("Use this feature if you want to exclude the first rows of your csv file from being uploaded. I generally recommend, however, to leave skip settings and provide the data as recommended in the readme:upload section.")
                )
              )
            )
    
  )

)
